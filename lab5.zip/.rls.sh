#!/bin/bash

rm -rf /config/language-server
mkdir -p /config/language-server
cd /config/language-server
wget http://download.eclipse.org/jdtls/milestones/0.26.0/jdt-language-server-0.26.0-201810021912.tar.gz
tar -xzf jdt-language-server-0.26.0-201810021912.tar.gz
rm jdt-language-server-0.26.0-201810021912.tar.gz

java \
  -Declipse.application=org.eclipse.jdt.ls.core.id1 \
  -Dosgi.bundles.defaultStartLevel=4 \
  -Declipse.product=org.eclipse.jdt.ls.core.product \
  -noverify \
  -Xmx256m \
  -XX:+UseConcMarkSweepGC \
  -jar \
  /config/language-server/plugins/org.eclipse.equinox.launcher_1.5.200.v20180922-1751.jar \
  -configuration \
  /config/language-server/config_linux \
  -data \
  /home/runner
