package app;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

public class UserLoader {

  private static final String REQUEST_URL = "" +
    "https://randomuser.me/api/" +
    "?results=%d" +
    "&format=pretty" +
    "&nat=us" +
    "&inc=gender,name,location,email,dob,phone" +
    "&noinfo";

  public static CompletableFuture<List<User>> getUsersAsync(int n) {
    HttpRequest request =
      HttpRequest.newBuilder()
        .uri(URI.create(String.format(REQUEST_URL, n)))
        .GET()
        .build();

    return
      HttpClient.newHttpClient()
        .sendAsync(request, BodyHandlers.ofString())
        .thenApply(HttpResponse::body)
        .thenApply(UserLoader::readUsers);
  }

  private static List<User> readUsers(String str) {
    try {
      ObjectMapper objectMapper = new ObjectMapper();
      objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
      return objectMapper.readValue(str, User.Wrapper.class).results;
    } catch (IOException e) {
      throw new UncheckedIOException(e);
    }
  }
}
