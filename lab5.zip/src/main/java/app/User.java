package app;

import java.util.List;

public class User {

  public String gender;
  public Name name;
  public Location location;
  public String email;
  public Date dob;
  public String phone;

  @Override
  public String toString() {
    return "" +
      "User{" +
      "gender=" + gender +
      ", name=" + name +
      ", location=" + location +
      ", email=" + email +
      ", dob=" + dob +
      ", phone=" + phone +
      "}";
  }

  public static class Name {

    public String first;
    public String last;

    @Override
    public String toString() {
      return first + " " + last;
    }
  }

  public static class Location {

    public String city;
    public String state;
    public String country;
    public int postcode;

    @Override
    public String toString() {
      return "" +
        "{" +
        "city=" + city +
        ", state=" + state +
        ", country=" + country +
        ", postcode=" + postcode +
        "}";
    }
  }

  public static class Date {
    
    public String date;

    @Override
    public String toString() {
      return date;
    }
  }

  public static class Wrapper {

    public List<User> results;
  }
}
