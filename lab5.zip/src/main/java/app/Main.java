package app;

import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main {

  private static void printUsers(List<User> users) {
    System.out.println("users:");
    for (User user : users) {
      System.out.println("  user:");
      System.out.println("    gender: " + user.gender);
      System.out.println("    name: " + user.name.first + " " + user.name.last);
      System.out.println("    location:");
      System.out.println("      city: " + user.location.city);
      System.out.println("      state: " + user.location.state);
      System.out.println("      country: " + user.location.country);
      System.out.println("      postcode: " + user.location.postcode);
      System.out.println("    email: " + user.email);
      System.out.println("    dob: " + user.dob);
      System.out.println("    phone: " + user.phone);
    }
  }

  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);

    System.out.println();
    System.out.println();

    printAndFlush("how many users do you want to get? ");
    int n = Integer.parseInt(scanner.nextLine());

    CompletableFuture<List<User>> future = UserLoader.getUsersAsync(n);

    printAndFlush("Loading users...");
    List<User> initialUsers = future.join();
    System.out.println(" Done.");

    Stream<User> stream = initialUsers.stream();
    Comparator<User> comparator = null;

    while (true) {
      System.out.println();
      System.out.println("options:");
      System.out.println(" 0) exit");
      System.out.println(" 1) print");
      System.out.println(" 2) reset");
      System.out.println(" 3) add sorting by gender");
      System.out.println(" 4) add sorting by name");
      System.out.println(" 5) add sorting by city");
      System.out.println(" 6) add sorting by dob");
      System.out.println(" 7) filter by gender equals x");
      System.out.println(" 8) filter by postcode > x and postcode < y");
      System.out.println(" 9) filter by name contains x");

      printAndFlush("i want to: ");
      int option = Integer.parseInt(scanner.nextLine());

      if (option == 0) {
        break;
      }

      if (stream == null && option != 2) {
        System.out.println("reset the stream first");  
        continue;
      }

      Comparator<User> newComparator = null;

      switch (option) {
        case 1:
          if (comparator != null) {
            stream = stream.sorted(comparator);
          }
          printUsers(stream.collect(Collectors.toUnmodifiableList()));
          stream = null;
          comparator = null;
          break;
        case 2:
          stream = initialUsers.stream();
          System.out.println("done");
          break;
        case 3:
          newComparator = Comparator.comparing(u -> u.gender);
          System.out.println("done");
          break;
        case 4:
          newComparator = Comparator.comparing(u -> u.name.first + " " + u.name.last);
          System.out.println("done");
          break;
        case 5:
          newComparator = Comparator.comparing(u -> u.location.city);
          System.out.println("done");
          break;
        case 6:
          newComparator = Comparator.comparing(u -> u.dob.date);
          System.out.println("done");
          break;
        case 7:
          printAndFlush("enter gener: ");
          String gender = scanner.nextLine();
          stream = stream.filter(u -> u.gender.equals(gender));
          System.out.println("done");
          break;
        case 8:
          printAndFlush("enter x: ");
          int x = Integer.parseInt(scanner.nextLine());
          printAndFlush("enter y: ");
          int y = Integer.parseInt(scanner.nextLine());
          stream = stream.filter(u -> u.location.postcode > x && u.location.postcode < y);
          System.out.println("done");
          break;
        case 9:
          printAndFlush("enter x: ");
          String str = scanner.nextLine();
          stream = stream.filter(u -> (u.name.first + " " + u.name.last).contains(str));
          System.out.println("done");
          break;
      }

      if (newComparator != null) {
        comparator = comparator != null
          ? comparator.thenComparing(newComparator)
          : newComparator;
      }
    }

    System.out.println();
    System.out.println();
  }

  private static void printAndFlush(String str) {    
    System.out.print(str);
    System.out.flush();;
  }
}
