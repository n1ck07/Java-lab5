package app;

import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;

public class App {

  public static void main(String[] args) throws Exception {
    ObjectMapper objectMapper = new ObjectMapper();
    String json = objectMapper.writeValueAsString(Map.of("foo", "bar"));
    System.out.println("hello world: " + json);
  }
}
